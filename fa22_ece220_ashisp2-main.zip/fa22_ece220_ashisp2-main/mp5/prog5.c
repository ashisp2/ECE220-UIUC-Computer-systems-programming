//mp5: by Ashis Pandey, UIN: 668368464, NETID: Ashisp2, in this MP, we will write a code to build a code breaker game. Briefly, we will generate seed which //generates random numbers and that will produce a solution code. With number of guesses less than 12, we need to guess the correct number by inputting all //4 digits in each trial. The code will tell whether you have perfect matches, misplaced matches or both. My general structure is first set seed, generate s//olution code after recieving seed value, set pointers to each solution code digits, compare that with each index of user guess with solution code using if// statements, the counters are set up that tells whether numbers are misplaced or perfect or both.



#include <stdio.h>
#include <stdlib.h>

#include "prog5.h"



static int guess_number;
static int solution1;   
static int solution2;
static int solution3;
static int solution4;





  

 
int set_seed (const char seed_str[])
 
{
   
  char post[20]; //  char post to be set anywhere 2+ so that it filters out any character in the seed value
  int x, ret;
  ret = sscanf(seed_str," %d%1s", &x, post);
  if (ret == 1){                                                      //ret =1 means checking if nothing is there besides the number character
    srand (x);
   

    return 1;  // ret = 1 means we got only the integers
  
  }else {

    printf ("set_seed: invalid seed\n");
      return 0;}
	 

}




void
start_game (int* one, int* two, int* three, int* four) //4 random numbers of the solution code, declaring pointer, its one instead of ptr one = pointer
{
    
   
  
    
  solution1=rand()%8 +1; // 0-8 we want 1-8, random mod 8 will set the range from 0 to 8, we want 1-8 so add 1
      solution2=rand()%8 + 1;
      solution3=rand()%8 + 1;
      solution4=rand()%8 + 1;

      *one = solution1;  //assign pointers to each
       *two = solution2;
	*three = solution3;
	*four = solution4;

	
	guess_number = 1;
	//	printf("solution set: %d %d %d %d", *one, *two, *three, *four);
      
      
														   
}



int
make_guess (const char guess_str[], int* one, int* two, 
	    int* three, int* four)
	{char post[20];
	  int x,y,z,w,perfect,misplaced, righti, rightii, rightiii, rightiv, ret;
	  ret = sscanf (guess_str, "%d%d%d%d%1s", &x, &y, &z, &w, post); //taking user input
	 *one = x;
	 *two = y;
	 *three = z;
	 *four = w;
	 perfect=0;
	 misplaced=0;
	 righti = 0;
	 rightii=0;
	 rightiii =0;
	 rightiv =0;
	 
	 if (ret ==4){      //we have 4 values x,y,z,w and we dont want any characters after that itwill go to post

	   if(w < 9 && x < 9 && y < 9 && z < 9){
//0th index
	     if (solution1 == x ){
		perfect++;
		righti = 1;
	     }
	      
//1st index
	      
	     if (y==solution2){
		perfect++;
		rightii = 1;}
	      
     

//2nd index
	      

	     if(solution3 == z){
		perfect++;
	      rightiii = 1;}
	     

//3rd index
	      ;
	     if(solution4 == w){
		perfect++;
		rightiv = 1;}

	     if(righti !=1){
	       if(x == solution2){
		 misplaced++;}
	       else if(x == solution3){
		 misplaced++;}
	       else if(x == solution4){
		 misplaced++;}
	     }

	     if(rightii != 1){
	       if(y == solution1){misplaced++;
	       }
	       else if (y == solution3){misplaced++;
	       }
	       else if (y == solution4){misplaced++;}
	     }

	     if(rightiii != 1){
	       if(z == solution1){misplaced++;}
	       else if(z == solution2){misplaced++;}
	       else if (z == solution4){misplaced++;}
	     }

	    if(rightiv != 1){
	       if(w  == solution1){misplaced++;}
	       else if(w == solution2){misplaced++;}
	       else if (w == solution3){misplaced++;}
	    }


	      printf ("With guess %d, you got %d  perfect matches and %d  misplaced matches\n",guess_number, perfect, misplaced );
	      guess_number++;
       } else{


	   printf ("make_guess: invalid guess\n");
	   return 0;

	}
       
  }
	 else{
	   printf("make_guess: invalid guess\n");
	   return 0;
	 }
	 return 1;
}	 


