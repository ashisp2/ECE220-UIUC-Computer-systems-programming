/*
 *NAME: ASHIS PANDEY
 *NETID: 668368464
 *The loop will iterate through each row element and print it to the screen until the end of the row has been reached, and the program is terminated. The pr*ogram can handle row indexes up to atleast the 40th index given that the result is stored as an unsigned long integer. */







#include <stdio.h>
#include <stdlib.h>

int main()
{
  int n, i ;
  unsigned int long  outputa;
  printf ("enter row index: ");
  scanf ("%d", &n); /* feed user data in variable n in the form of decimal*/
  printf ("\n"); /* just putting newline after user input to display result in the new line */

  outputa = 1; /* initialize outputa */
  printf("%lu", outputa);
  for (i = 1; i <= n; i++){
    outputa = ((n + 1 - i)*outputa)/i; /* formula as given in the mp3 ece220 wikipage. to calculate pascal's triangle coefficients */
    printf("%lu", outputa); /*print output in the form of unsigned integer or  unsigned long integer */
}

  printf ("\n");
    return 0;
}
