#ifndef PRIME_H
#define PRIME_H

int is_prime(int n);
  
  
#endif
