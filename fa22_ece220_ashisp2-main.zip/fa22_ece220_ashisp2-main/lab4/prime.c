#include "prime.h"

int is_prime(int n){
  // Return 1 if n is a prime, and 0 if it is not
  return 0;
}

