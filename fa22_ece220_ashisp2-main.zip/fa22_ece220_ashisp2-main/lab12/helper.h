#ifndef H_HELPER
#define H_HELPER
double calculate_phase(double a, double b);

#endif