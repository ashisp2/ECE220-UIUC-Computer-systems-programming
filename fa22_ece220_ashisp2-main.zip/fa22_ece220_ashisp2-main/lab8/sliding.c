#include "sliding.h"
/*  Slide all values of array up
*/
//Lab8:by Ashis, in this lab, we will implement a part of the actual mp8 which is slide up function of 2048 game. empty cell contains  minus 1, 1's and 2's are the numbers inside the cell.
void slide_up(int* my_array, int rows, int cols){

  int i, j;
	for(i = 0; i < cols; i++)
	{
		for(j = 1; j < rows; j++)
		{
			if(my_array[j*cols + i] != -1)
			{
				int k = 0;
				while(k < j)
				{
					if(my_array[k*cols + i] == -1)
					{
					  break;// find the first empty cell  in column and break.
					}
					k++;
				}
				if(k < j) // if k is not less than j, we cant shift
				{
					my_array[k*cols + i] = my_array[j*cols + i];
					my_array[j*cols + i] = -1; 
				}
			}
		}
	}

    return;
}
