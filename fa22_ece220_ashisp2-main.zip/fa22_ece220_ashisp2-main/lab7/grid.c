#include <stdio.h>
#include "grid.h"
#include "grid_provided.h"


// Procedure: parse_grid: 
/* Pseudocode algorithm: 
	open the file for reading
	make sure the file is valid
	for each row and column
		scan the file to read the next int into grid at (row, column)
	close the file
*/
//
void parse_grid(const char fpath[], int grid[5][5]) {
 
}

// Procedure: solve_grid
// Solve the given grid instance. See wiki for algorithm.
int solve_grid(int grid[5][5]) {

	return 0;
}
