void updateBoard(int* board, int boardRowSize, int boardColSize);
int countLiveNeighbor(int* board, int boardRowSize, int boardColSize, int row, int col);
int aliveStable(int* board, int boardRowSize, int boardColSize);
