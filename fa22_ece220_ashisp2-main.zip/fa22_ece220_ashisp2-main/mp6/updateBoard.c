/*Name:Ashis Pandey, Ashisp2, in this mp, we are creating functions for game of life. We have 3 functions where first one counts the number of live neighbors, I have some nested for loops and if conditions to go over each neighboring cells and check whether its 1 or0. also remember do not read the cell that you are checking the neighbors for. So I used row and column not equals... you wanna do row-1, column -1 or plus one so that you are limiting the neighbors to only the cells that you are interested. Updateboard function goes through every loop and calls countlive neighbor. Use the conditions given in MP instructions in this function. In alive stable, I copy the contents of board into new board update the board and compare whether they are stable/same.
* countLiveNeighbor
 * Inputs:
 * board: 1-D array of the current game board. 1 represents a live cell.
 * 0 represents a dead cell
 * boardRowSize: the number of rows on the game board.
 * boardColSize: the number of cols on the game board.
 * row: the row of the cell that needs to count alive neighbors.
 * col: the col of the cell that needs to count alive neighbors.
 * Output:
 * return the number of alive neighbors. There are at most eight neighbors.
 * Pay attention for the edge and corner cells, they have less neighbors.
 */

int countLiveNeighbor(int* board, int boardRowSize, int boardColSize, int row, int col){ // pointers duality concept  pointers can be treated as array so thats why i put board[] in line 26, not without it.
 // row and column is current index that we use to check neighbours.

int liveNeighbors = 0;
int i, j;

for(i = (row-1); i <= (row+1); i++){ //loop through neighoring rows
        if(i >= 0 && i < boardRowSize){ //check if the row is within the board boundaries
            for(j = (col-1); j <= (col+1); j++){ //loop though the neighboring columns
                if(j>=0 && j<boardColSize){ //check if the column is within bounds where do we use the pointers?
		  if(i!=row || j!=col){// dont include actual value as a neighbor note why && is wrong but instead it is ||, just make the truth table and see which logic it follows.
		    if(board[(i*boardColSize +j)]==1)// 
		      liveNeighbors++; 
                    }
                }
            }
        }
    }
return liveNeighbors;
}
/*
 * Update the game board to the next step.
 * Input: 
 * board: 1-D array of the current game board. 1 represents a live cell.
 * 0 represents a dead cell
 * boardRowSize: the number of rows on the game board.
 * boardColSize: the number of cols on the game board.
 * Output: board is updated with new values for next step.
 */





void updateBoard(int* board, int boardRowSize, int boardColSize) { // void means you wont be able to store the value in whatever function the update board outputs such as int Neighbor = countliveneighbor() you cant leave this bracket blank, you need to put in (not values), but variables as a parameter.... 
int i, j;
int num_elements;
int deep_copy[boardColSize*boardRowSize]; // initialized deep_copy
num_elements = boardColSize*boardRowSize;

for(i =0; i < num_elements; i++){
  deep_copy[i] = board[i];
 }


// i am copying original board here.

// in this partivula cell,first check if cell is alive or dead... if alive and if no of liveneighbors is <2, update to new board by changing that cell to 0.
for(i = 0; i<boardRowSize; i++){
  for(j = 0; j<boardColSize; j++){

    //what i did.... countLiveNeighbor(x)
    // int Neighbor = countLiveNeighbor() what do you want to put as an arguement.... think... so.. 
    int Neighbor = countLiveNeighbor(deep_copy, boardRowSize, boardColSize, i, j); // this i and j will do the job to go through each and every cell and count the number of live neighbors in that cell.

if(board[(i*boardColSize +j)]==1){ // check if cell content is 1 or 0 // dont do( i*boardColSize + j ) do board[i*boardColSize+j]
	  if(Neighbor  ==  2 || Neighbor == 3){
	    board[(i*boardColSize +j)] = 1;
		  }// update the current board by 1 we will overwrite the current board but dont worry we have copy of it.
	  else  if(Neighbor >3 || Neighbor < 2){
	        board[(i*boardColSize +j)] = 0;
	      }// i dont know whether i should put elseif

}else if (board[(i*boardColSize+j)] == 0){ // only for dead cell
			if(Neighbor == 3){
	 board[(i*boardColSize +j)] = 1;

	 // what about any dead cell other than exactly 3??
}else{
	 board[(i*boardColSize + j)] = 0;
	   }
	     
			}
     }

}
}


	       //  this function will update the board , we have the original board(before clalinf updateboard) saved in deep copy
          //board is the new board

/*
 * aliveStable
 * Checks if the alive cells stay the same for next step
 * board: 1-D array of the current game board. 1 represents a live cell.
 * 0 represents a dead cell
 * boardRowSize: the number of rows on the game board.
 * boardColSize: the number of cols on the game board.
 * Output: return 1 if the alive cells for next step is exactly the same with 
 * current step or there is no alive cells at all.
 * return 0 if the alive cells change for the next step.
 */ 
int aliveStable(int* board, int boardRowSize, int boardColSize){


	       int i,j, num_elements;
		   int newboard[boardColSize*boardRowSize];
		   num_elements = boardColSize*boardRowSize;
			for(i =0; i < num_elements; i++){
 			    newboard[i] = board[i];
 					}
						
		   // do copy of the board
	       updateBoard(newboard, boardRowSize, boardColSize);  //if current board stays the same

	       for(i = 0; i< boardRowSize; i++){
		      for(j = 0; j<boardColSize; j++){
		   
		        if(newboard[(i*boardColSize + j)] != board[(i*boardColSize + j)] ){
		    return 0;
		   }
		   
		 }
	       }
	       
	     return 1;
}
