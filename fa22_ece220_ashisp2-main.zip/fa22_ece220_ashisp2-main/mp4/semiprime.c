#include <stdlib.h>
#include <stdio.h>

// This program willprint semiprimes based on given range. it reads two inputs and then prints aa the semi primes within that range. Semiprime is a positive integer number that is a product of two prime numbers. I fixed the is_prime function so that it prints out the correct prime number.I set up a counter that counts increments whenver remainder of a and every number from 0 to a is 0, if we have more than two factors of number thats divisible, we know it is not a prime so return 0 and viceversa. In semi_primes, the problem was first we werent returning the return values so i set ret = 1 whenever the for loop successfully runs. Another changes was I put the break statement because we want to get out of the inner for loop so that we can increment i.
/*
 * is_prime: determines whether the provided number is prime or not
 * Input    : a number
 * Return   : 0 if the number is not prime, else 1
 */
int is_prime(int number)
{
    int i;
    int counter = 0;
    if (number <= 1) {return 0;}
    for (i = 1; i <= number; i++) { //for each number smaller than it
        if (number % i == 0) { //check if the remainder is 0
            counter++;
        }
    }
    if(counter == 2)
     return 1;
    else
      return 0;
}


/*
 * print_semiprimes: prints all semiprimes in [a,b] (including a, b).
 * Input   : a, b (a should be smaller than or equal to b)
 * Return  : 0 if there is no semiprime in [a,b], else 1
 */
int print_semiprimes(int a, int b)
{
    int i, j, k;
    int ret = 0;
    for (i = a; i <=b; i++) { //for each item in interval
        //check if semiprime
        for (j = 2; j <= i; j++) {
            if (i%j == 0) {
                if (is_prime(j)) {
                    k = i/j;
                    if (is_prime(k)) {
                        printf("%d ", i);
			ret = 1;
			break;
                    }
                }
            }
        }

    }
    printf("\n");
    return ret;

}
