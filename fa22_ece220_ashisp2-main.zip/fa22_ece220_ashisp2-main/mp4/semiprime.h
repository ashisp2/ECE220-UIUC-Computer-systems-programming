#ifndef SEMIPRIME_H
#define SEMIPRIME_H

int is_prime(int number);
int print_semiprimes(int a, int b);


#endif
