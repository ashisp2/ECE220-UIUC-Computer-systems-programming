#include <stdio.h>
#include <math.h>

#define M_PI 3.14159265358979323846

/*
 * main
 *  DESCRIPTION: compute a set of points of a function and print the results
 *  INPUTS: console (int, float float) -- equation related constants
 *  OUTPUTS: console (x, f(x)) -- sequence of values to be printed
 *  RETURN VALUE: 0
 *  SIDE EFFECTS: none
 */
int main()
{
  int n;
  float w1;
  float w2;
  float x, out;
  int i;

    // Prompt user for input
  scanf("%d %f %f", &n, &w1, &w2);
    // Get user input
  for(i=0; i<n; i++){
    x =i*M_PI / n;
    out = sin(w1 * x) + 0.5 * sin(w2 * x);
    printf("(%f, %f)\n", x, out);
  }
 

    // Compute function output
    /* for i from 0 to n-1
     *     compute and print xi and f(xi)
     *     use sin() function from math.h
     */

    return 0;
}

