//Function for generating three d6 rolls

void roll_three(int* one, int* two, int* three){

}
